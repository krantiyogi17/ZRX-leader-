ZRX LEADER Android Studio project

This is source code for a legitimate Free Fire settings/practice companion.
It does NOT contain auto-aim, aimbot, auto-headshot, game injection, memory editing,
or anti-cheat bypass functionality.

To build:
1. Install Android Studio.
2. Open this folder as an existing project.
3. Allow Gradle sync and install the Android SDK requested by Android Studio.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).

The generated APK is created by Android Studio on your computer. This ZIP is the
editable source project, not an already-built APK.
